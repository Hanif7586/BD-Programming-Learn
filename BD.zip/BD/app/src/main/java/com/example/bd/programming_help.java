package com.example.bd;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class programming_help extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_programming_help);
    }
}