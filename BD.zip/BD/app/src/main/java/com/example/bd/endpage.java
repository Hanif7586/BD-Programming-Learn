package com.example.bd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class endpage extends AppCompatActivity {
    private WebView webViewh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_endpage);



        webViewh=findViewById(R.id.hanifIDD);
        WebSettings webSettings= webViewh.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webViewh.setWebViewClient(new WebViewClient());
        webViewh.loadUrl("https://sites.google.com/view/hanif-hst/contact");
    }


    @Override
    public void onBackPressed() {
        if(webViewh.canGoBack())
        {
            webViewh.goBack();
        }
        else{
            super.onBackPressed();
        }

    }
}