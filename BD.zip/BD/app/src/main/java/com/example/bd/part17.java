package com.example.bd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class part17 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_part17);
    }
}